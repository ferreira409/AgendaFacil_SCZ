# Diagrama entidad-relación — AgendaFácil SCZ

```mermaid
erDiagram
    USUARIOS ||--o{ NEGOCIOS : "es dueño de"
    USUARIOS ||--o{ CITAS : "reserva"
    USUARIOS ||--o{ CALIFICACIONES : "escribe"
    USUARIOS ||--o{ PASSWORD_RESETS : "solicita"
    USUARIOS ||--o{ API_TOKENS : "tiene"
    NEGOCIOS ||--o{ SERVICIOS : "ofrece"
    NEGOCIOS ||--o{ HORARIOS : "atiende en"
    NEGOCIOS ||--o{ DIAS_LIBRES : "cierra en"
    NEGOCIOS ||--o{ CITAS : "recibe"
    NEGOCIOS ||--o{ CALIFICACIONES : "recibe"
    SERVICIOS ||--o{ CITAS : "se reserva en"
    CITAS ||--o| CALIFICACIONES : "puede tener"

    USUARIOS {
        int id PK
        varchar nombre
        varchar email UK
        varchar telefono
        varchar password "hash bcrypt"
        enum rol "cliente | negocio | admin"
        tinyint activo
        timestamp creado_en
    }
    NEGOCIOS {
        int id PK
        int usuario_id FK
        varchar nombre
        varchar categoria
        varchar icono
        varchar zona
        varchar direccion
        varchar telefono
        varchar whatsapp
        text descripcion
        varchar foto
        tinyint activo
    }
    SERVICIOS {
        int id PK
        int negocio_id FK
        varchar nombre
        int duracion_min
        decimal precio
    }
    HORARIOS {
        int id PK
        int negocio_id FK
        tinyint dia "1 lunes - 7 domingo"
        time abre
        time cierra
    }
    DIAS_LIBRES {
        int id PK
        int negocio_id FK
        date fecha
        varchar motivo
    }
    CITAS {
        int id PK
        int usuario_id FK
        int negocio_id FK
        int servicio_id FK
        date fecha
        time hora
        time hora_fin
        enum estado "pendiente | confirmada | cancelada | completada"
        varchar notas
    }
    CALIFICACIONES {
        int id PK
        int cita_id FK "único"
        int usuario_id FK
        int negocio_id FK
        tinyint estrellas "1 a 5"
        varchar comentario
    }
    PASSWORD_RESETS {
        int id PK
        int usuario_id FK
        char token_hash
        datetime expira
        tinyint usado
    }
    API_TOKENS {
        int id PK
        int usuario_id FK
        char token_hash
        datetime expira
    }
    INTENTOS_LOGIN {
        int id PK
        varchar email
        varchar ip
        timestamp creado_en
    }
```

## Descripción de las tablas

| Tabla | Para qué sirve |
|---|---|
| `usuarios` | Clientes, vendedores y administradores. El campo `rol` define los permisos. |
| `negocios` | Datos públicos de cada negocio. Un vendedor puede tener uno o más. |
| `servicios` | Lo que ofrece cada negocio, con duración (minutos) y precio (Bs). |
| `horarios` | Horario semanal. Si un día no tiene fila, el negocio está cerrado. |
| `dias_libres` | Feriados o vacaciones en los que no se puede reservar. |
| `citas` | Reservas. `hora_fin` = `hora` + duración, se usa para evitar choques. |
| `calificaciones` | Una opinión (1 a 5 estrellas) por cada cita completada. |
| `password_resets` | Enlaces de recuperación de contraseña (1 hora, un solo uso). |
| `api_tokens` | Sesiones de la app móvil (30 días). |
| `intentos_login` | Intentos fallidos, para bloquear ataques de fuerza bruta. |
