# API REST — AgendaFácil SCZ

API en JSON pensada para una app móvil (Flutter, React Native, Kotlin, etc.).
Usa la **misma base de datos y las mismas reglas** que la página web.

- **URL base (local):** `http://localhost:8000/api`
- **Formato:** enviar y recibir `application/json`
- **Autenticación:** token Bearer en la cabecera
  ```
  Authorization: Bearer <token>
  ```
  El token se obtiene con `POST /auth/login` y dura 30 días.
- **Errores:** siempre `{"ok": false, "error": "mensaje"}` con el código HTTP correspondiente
  (`401` sin sesión, `403` sin permiso, `404` no existe, `409` horario ocupado, `422` datos inválidos).

## Autenticación

### `POST /auth/login`
```json
{ "email": "cliente@agendafacil.com", "password": "123456" }
```
Respuesta `200`:
```json
{ "ok": true, "token": "a3f9...", "expira_en_dias": 30,
  "usuario": { "id": 3, "nombre": "Ana Pérez", "email": "cliente@agendafacil.com", "telefono": "70000002", "rol": "cliente" } }
```
Bloquea al quinto intento fallido durante 15 minutos.

### `POST /auth/registro`
```json
{ "tipo": "cliente", "nombre": "Juan", "email": "juan@mail.com", "telefono": "70012345", "password": "clave1234" }
```
Para negocio: `"tipo": "negocio"` + `"negocio"`, `"categoria"`, `"zona"`, `"direccion"`. Respuesta `201`.

### `POST /auth/logout` 🔒
Invalida el token.

### `GET /yo` 🔒
Datos del usuario del token.

## Listas
- `GET /categorias` → `["Barbería", "Peluquería", ...]`
- `GET /zonas` → `["Centro", "Equipetrol", "Norte", "Urubó", ...]`

## Negocios

### `GET /negocios?q=&categoria=&zona=`
Lista de negocios activos (filtros opcionales), ordenados por calificación.
```json
{ "ok": true, "total": 1, "negocios": [
  { "id": 1, "nombre": "Barbería El Corte", "categoria": "Barbería", "zona": "Equipetrol",
    "direccion": "Av. San Martín, 3er anillo", "telefono": "33300001", "whatsapp": "59170000001",
    "descripcion": "...", "foto": "https://...", "promedio": 5.0, "total_calificaciones": 1, "precio_desde": 50.0 } ] }
```

### `GET /negocios/{id}`
Detalle con `servicios`, `horarios` (día 1 = lunes … 7 = domingo) y `resenas`.

### `GET /negocios/{id}/disponibilidad?servicio={id}&fecha=AAAA-MM-DD`
Horas libres para ese servicio, teniendo en cuenta horario, días libres, duración y citas existentes.
```json
{ "ok": true, "fecha": "2026-10-19", "abierto": true,
  "horario": { "abre": "09:00", "cierra": "19:00" },
  "servicio": { "id": 2, "duracion_min": 60 },
  "horas": ["09:00", "09:30", "11:00", "11:30"] }
```

## Citas 🔒

### `GET /citas?estado=&fecha=`
- Cliente: sus citas.
- Vendedor: citas de su negocio. Admin: todas.

### `POST /citas` (solo cliente)
```json
{ "negocio_id": 1, "servicio_id": 2, "fecha": "2026-10-19", "hora": "11:00", "notas": "opcional" }
```
`201` con la cita creada, o `409` si la hora ya no está libre.

### `PATCH /citas/{id}`
```json
{ "estado": "confirmada" }
```
| Quién | Puede |
|---|---|
| Cliente | `cancelada` (solo sus citas) |
| Vendedor / Admin | `confirmada`, `completada`, `cancelada` |

Transiciones válidas: `pendiente → confirmada / cancelada`, `confirmada → completada / cancelada`.

### `POST /citas/{id}/calificar` (solo cliente, cita completada)
```json
{ "estrellas": 5, "comentario": "Excelente atención" }
```

## Probar la API

Con **curl** (en Cmder):
```bash
curl -X POST http://localhost:8000/api/auth/login -H "Content-Type: application/json" -d "{\"email\":\"cliente@agendafacil.com\",\"password\":\"123456\"}"

curl http://localhost:8000/api/citas -H "Authorization: Bearer EL_TOKEN"
```
También se puede usar **Postman** o **Thunder Client** (extensión de VS Code).

> En Apache/hosting la API funciona gracias al `.htaccess`. Si el hosting no permite
> reescritura de URLs, usar `api/index.php?ruta=negocios/1`.
