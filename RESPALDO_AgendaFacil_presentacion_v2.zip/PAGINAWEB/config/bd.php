<?php
// =========================================================
//  Conexión PDO a MySQL (la usan la web y la API)
// =========================================================
require_once __DIR__ . '/config.php';

function conectarBD() {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    // Misma zona horaria en MySQL que en PHP (Bolivia, UTC-4)
    $pdo->exec("SET time_zone = '-04:00'");
    return $pdo;
}
