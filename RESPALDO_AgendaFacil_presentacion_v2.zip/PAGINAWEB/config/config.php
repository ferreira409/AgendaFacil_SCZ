<?php
// =========================================================
//  CONFIGURACIÓN GENERAL
//  Cambia estos valores al subir la página a un hosting.
// =========================================================

// --- Base de datos (Laragon por defecto: root sin contraseña) ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'agendafacil');
define('DB_USER', 'root');
define('DB_PASS', '');

// --- Ruta base del sitio ---
//   php -S localhost:8000 router.php   -> '/'
//   C:\laragon\www\PAGINAWEB            -> '/PAGINAWEB/'
//   Hosting (raíz del dominio)          -> '/'
define('BASE_URL', '/');

define('NOMBRE_SITIO', 'AgendaFácil');
define('CIUDAD', 'Santa Cruz de la Sierra');

// --- Modo demostración ---
// true: el enlace para recuperar contraseña se muestra en pantalla (no hay correo).
// En producción, cámbialo a false y envía el enlace por correo.
define('MODO_DEMO', true);

// --- Reservas ---
define('INTERVALO_MIN', 30);          // cada cuántos minutos se ofrece un horario
define('DIAS_MAX_RESERVA', 60);       // con cuántos días de anticipación se puede reservar

// --- Seguridad ---
define('MAX_INTENTOS_LOGIN', 5);      // intentos fallidos permitidos...
define('MINUTOS_BLOQUEO', 15);        // ...en esta cantidad de minutos
define('DIAS_TOKEN_API', 30);         // duración del token de la app móvil

// --- Fotos subidas por los negocios ---
define('MAX_FOTO_MB', 2);
define('CARPETA_FOTOS', 'imagenes/negocios/');

date_default_timezone_set('America/La_Paz');
